import torch
import torch.nn as nn
import torch.optim as optim
from .base_classifier import BaseClassifier

class CustomMLPClassifier(BaseClassifier):
    """
    Custom classifier based on the previous SimpleCNN architecture.
    This replicates the exact classifier part of the original SimpleCNN model.
    """
    
    def __init__(self, input_dim: int, num_classes: int, learning_rate: float = 0.001, num_epochs: int = 100, **kwargs):
        super().__init__(input_dim, num_classes, **kwargs)

        self.learning_rate = learning_rate
        self.num_epochs = num_epochs
        
        # Exact classifier architecture from original SimpleCNN
        # Linear(128 * 28 * 28 + 2, 256) -> ReLU -> Dropout(0.2) -> Linear(256, num_classes)
        self.classifier = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),  # Original dropout rate was 0.2
            nn.Linear(256, num_classes),
        )
        
        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = optim.Adam(self.classifier.parameters(), lr=self.learning_rate)
        
        # Ensure all parameters are float32
        self.classifier.float()
        self.float()

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        return self.classifier(X)
    
    def fit(self, X: torch.Tensor, y: torch.Tensor) -> None:
        """
        Fit the custom classifier to the training data.
        
        Args:
            X: Training features of shape (n_samples, input_dim)
            y: Training labels of shape (n_samples,)
        """
        self.classifier.train()
        
        # Convert to tensors if needed
        if not isinstance(X, torch.Tensor):
            X = torch.tensor(X, dtype=torch.float32)
        if not isinstance(y, torch.Tensor):
            y = torch.tensor(y, dtype=torch.long)
        
        # Training loop
        for epoch in range(self.num_epochs):
            self.optimizer.zero_grad()
            
            # Forward pass
            outputs = self.forward(X)
            loss = self.criterion(outputs, y)
            
            # Backward pass
            loss.backward()
            self.optimizer.step()
    
    def predict(self, X: torch.Tensor) -> torch.Tensor:
        """
        Predict class labels for samples in X.
        
        Args:
            X: Features of shape (n_samples, input_dim)
            
        Returns:
            Predicted class labels of shape (n_samples,)
        """
        self.classifier.eval()
        
        if not isinstance(X, torch.Tensor):
            X = torch.tensor(X, dtype=torch.float32)
        
        with torch.no_grad():
            outputs = self.forward(X)
            _, predicted = torch.max(outputs, 1)
            return predicted
    
    def predict_proba(self, X: torch.Tensor) -> torch.Tensor:
        """
        Predict class probabilities for samples in X.
        
        Args:
            X: Features of shape (n_samples, input_dim)
            
        Returns:
            Predicted class probabilities of shape (n_samples, num_classes)
        """
        self.classifier.eval()
        
        if not isinstance(X, torch.Tensor):
            X = torch.tensor(X, dtype=torch.float32)
        
        with torch.no_grad():
            outputs = self.forward(X)
            return torch.softmax(outputs, dim=1)
