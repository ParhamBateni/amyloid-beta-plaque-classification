import torch
import torch.nn as nn
from models.config import Config
from models.model_factory import ModelFactory
from typing import Optional, Iterable
from tqdm import tqdm
from utils import print_log
class SupervisedModel(nn.Module):
    """
    Supervised learning model that combines a feature extractor and a classifier.
    Supports freezing the feature extractor for transfer learning scenarios.
    """
    
    def __init__(self, config: Config):
        super().__init__()
        
        # Parse names and device from config
        self.feature_extractor_name = config.supervised.supervised_config.feature_extractor_name
        self.feature_extractor_config = config.supervised.supervised_config.feature_extractor
        self.classifier_name = config.supervised.supervised_config.classifier_name
        self.classifier_config = config.supervised.supervised_config.classifier
        
        self.num_classes = len(config.name_to_label)
        self.num_epochs = config.supervised.supervised_config.training.num_epochs
        self.learning_rate = config.supervised.supervised_config.training.learning_rate
        self.weight_decay = config.supervised.supervised_config.training.weight_decay
        self.early_stop = config.supervised.supervised_config.training.early_stop
        self.log_mode = config.general_config.system.log_mode
        self.device = config.general_config.system.device

        # Create feature extractor using nested config under 'feature_extractor'
        self.feature_extractor = ModelFactory.create_feature_extractor(
            feature_extractor_name=self.feature_extractor_name,
            feature_extractor_config=config.supervised.feature_extractors_config[self.feature_extractor_name].to_dict(),
        )
        
        self.use_extra_features = config.general_config.data.use_extra_features
        self.image_feature_dim = self.feature_extractor.get_output_dim()
        self.extra_feature_dim = config.general_config.data.extra_feature_dim

        
        # Create classifier using nested config under 'classifier'
        self.classifier = ModelFactory.create_classifier(
            classifier_name=self.classifier_name,
            input_dim=self.image_feature_dim + self.extra_feature_dim if self.use_extra_features else self.image_feature_dim,
            num_classes=self.num_classes,
            classifier_config=config.supervised.classifiers_config[self.classifier_name].to_dict(),
        )
        
        # Move to device
        self.to(self.device)

    def train_model(
        self,
        train_dataloader: Iterable,
        val_dataloader: Iterable,
    ) -> None:
        """Train the supervised model with early stopping and logging."""

        print_log(
            f"Starting supervised training for {self.num_epochs} epochs",
            log_mode=self.log_mode,
        )

        # Setup optimizer and loss over trainable params
        trainable_params = [p for p in self.parameters() if p.requires_grad]
        optimizer = torch.optim.Adam(trainable_params, lr=self.learning_rate, weight_decay=self.weight_decay)
        criterion = nn.CrossEntropyLoss().float()

        best_val_loss = float("inf")
        patience_counter = 0

        for epoch in range(self.num_epochs):
            # Training phase
            self.train()
            train_loss = 0.0
            train_correct = 0
            train_total = 0
            for batch_idx, (image_paths, raw_images, transformed_images,normalized_raw_images, normalized_transformed_images, extra_features, labels) in enumerate(
                tqdm(
                    train_dataloader,
                    desc=f"Epoch {epoch+1}/{self.num_epochs} - Training",
                )
            ):
                normalized_transformed_images = normalized_transformed_images.to(self.device)
                extra_features = extra_features.to(self.device)
                labels = labels.to(self.device)

                optimizer.zero_grad()
                outputs = self(normalized_transformed_images, extra_features if self.use_extra_features else None)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                train_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                train_total += labels.size(0)
                train_correct += (predicted == labels).sum().item()

            # Validation phase
            self.eval()
            val_loss = 0.0
            val_correct = 0
            val_total = 0

            with torch.no_grad():
                for image_paths, raw_images, transformed_images,normalized_raw_images, normalized_transformed_images, extra_features, labels in tqdm(
                    val_dataloader,
                    desc=f"Epoch {epoch+1}/{self.num_epochs} - Validation",
                ):
                    normalized_transformed_images = normalized_transformed_images.to(self.device)
                    extra_features = extra_features.to(self.device) if self.use_extra_features else None
                    labels = labels.to(self.device)

                    outputs = self(normalized_transformed_images, extra_features if self.use_extra_features else None)
                    loss = criterion(outputs, labels)

                    val_loss += loss.item()
                    _, predicted = torch.max(outputs.data, 1)
                    val_total += labels.size(0)
                    val_correct += (predicted == labels).sum().item()

            # Calculate metrics
            train_acc = 100 * train_correct / train_total
            val_acc = 100 * val_correct / val_total
            avg_train_loss = train_loss / len(train_dataloader)
            avg_val_loss = val_loss / len(val_dataloader)

            print_log(
                f"Epoch {epoch+1}/{self.num_epochs}:",
                log_mode=self.log_mode,
            )
            print_log(
                f"  Train Loss: {avg_train_loss:.4f}, Train Acc: {train_acc:.2f}%",
                log_mode=self.log_mode,
            )
            print_log(
                f"  Val Loss: {avg_val_loss:.4f}, Val Acc: {val_acc:.2f}%",
                log_mode=self.log_mode,
            )

            # Early stopping and checkpointing
            if avg_val_loss < best_val_loss:
                best_val_loss = avg_val_loss
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= self.early_stop:
                    print_log(
                        f"Early stopping triggered after {epoch+1} epochs",
                        log_mode=self.log_mode,
                    )
                    break

    def test_model(
        self,
        test_dataloader: Iterable,
    ):
        """Test the supervised model and return labels and predictions."""

        print_log(
            "Testing supervised model", log_mode=self.log_mode
        )

        self.eval()

        all_labels = []
        all_preds = []

        with torch.no_grad():
            for image_paths, raw_images, transformed_images,normalized_raw_images, normalized_transformed_images, extra_features, labels in tqdm(test_dataloader, desc="Testing"):
                # raw_images = raw_images.to(self.device)
                normalized_transformed_images = normalized_transformed_images.to(self.device)
                extra_features = extra_features.to(self.device) if self.use_extra_features else None
                labels = labels.to(self.device)

                outputs = self(normalized_transformed_images, extra_features if self.use_extra_features else None)
                _, predicted = torch.max(outputs.data, 1)

                all_labels.extend(labels.cpu().numpy())
                all_preds.extend(predicted.cpu().numpy())

        return all_labels, all_preds

    def forward(self, x_image: torch.Tensor, x_features: torch.Tensor = None) -> torch.Tensor:
        """
        Forward pass through the supervised model.
        
        Args:
            x_image: Image tensor of shape (batch_size, channels, height, width)
            x_features: Additional features tensor of shape (batch_size, feature_dim)
            
        Returns:
            Model output
        """
        # Extract features
        image_features = self.feature_extractor(x_image)
        if x_features is not None:
            combined_features = torch.cat([image_features, x_features], dim=1)
        else:
            combined_features = image_features

        return self.classifier(combined_features)
    
    def extract_features(self, x_image: torch.Tensor) -> torch.Tensor:
        """
        Extract features using the feature extractor.
        
        Args:
            x_image: Image tensor
            
        Returns:
            Extracted features
        """
        return self.feature_extractor(x_image)
    
    
    def predict(self, X: torch.Tensor) -> torch.Tensor:
        """
        Predict using the classifier.
        
        Args:
            X: Feature tensor
            
        Returns:
            Predictions
        """
        return self.classifier.predict(X)
    
    def predict_proba(self, X: torch.Tensor) -> torch.Tensor:
        """
        Predict probabilities using the classifier.
        
        Args:
            X: Feature tensor
            
        Returns:
            Prediction probabilities
        """
        return self.classifier.predict_proba(X)
