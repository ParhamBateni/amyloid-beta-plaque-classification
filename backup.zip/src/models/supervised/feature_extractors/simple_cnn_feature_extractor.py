import torch
import torch.nn as nn
from .base_feature_extractor import BaseFeatureExtractor

class SimpleCNNFeatureExtractor(BaseFeatureExtractor):
    """
    Simple CNN feature extractor.
    """
    
    def __init__(self, input_dim: int, freeze_feature_extractor: bool = False,  output_dim: int = 28):
        super().__init__(input_dim, freeze_feature_extractor)
        self.output_dim = output_dim
        self.feature_extractor = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            # nn.Dropout2d(0.1),
            
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            # nn.Dropout2d(0.1),
            
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            # nn.Dropout2d(0.1),
            
            # Add one more pooling layer to reduce feature space
            nn.AdaptiveAvgPool2d((self.output_dim, self.output_dim)),
            nn.Flatten()
        )
        # Ensure all parameters are float32
        self.float()
    
    def forward(self, x_image: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the feature extractor.
        
        Args:
            x_image: Image tensor of shape (batch_size, channels, height, width)
            
        Returns:
            Combined features tensor
        """
        image_features = self.feature_extractor(x_image)
        return image_features