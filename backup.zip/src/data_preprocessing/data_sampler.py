import h5py
import numpy as np
import pandas as pd
import os
from tqdm import tqdm
import argparse
import sys
import random
from PIL import Image
import shutil
def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, default="data")
    parser.add_argument("--unlabeled_sample_size", type=int, default=2000, 
                       help="Number of unlabeled plaques to sample (default: 2000)")
    parser.add_argument("--random_seed", type=int, default=42,
                       help="Random seed for reproducible sampling (default: 42)")
    parser.add_argument("--output_file", type=str, default="data_table_sampled.csv",
                       help="Output CSV file name (default: data_table_sampled.csv)")
    parser.add_argument("--label_file", type=str, default="labelfileidx.npz",
                       help="Label file name (default: labelfileidx.npz)")
    parser.add_argument("--downsample_size", type=int, nargs=2, default=[224, 224],
                       help="Downsample size for images (default: 224 224)")
    parser.add_argument("--save_images", action="store_true", default= True,
                       help="Save downsampled images to folders")
    return parser.parse_args()

def get_total_plaques_count(data_folder):
    """Count total number of plaques across all files"""
    files = os.listdir(os.path.join(data_folder, 'images'))
    total_plaques = 0
    
    print("Counting total plaques...")
    for image in tqdm(files, desc="Counting plaques"):
        file_path = os.path.join(data_folder, 'images', image)
        try:
            with h5py.File(file_path, 'r') as f:
                total_plaques += f['plaques'].attrs['length']
        except Exception as e:
            print(f"Error counting plaques in {image}: {e}")
    
    return total_plaques, files

def create_data_table(data_folder, unlabeled_sample_size, label_file, random_seed=42, 
                                            save_images=False, downsample_size=(224, 224), label_names_file=None):
    """Create data table with labeled samples from npz file and sampled unlabeled data, optionally saving images"""
    random.seed(random_seed)
    
    # Load label names if saving images
    label_to_name = {}
    if save_images and label_names_file and os.path.exists(os.path.join(data_folder, label_names_file)):
        try:
            label_name_df = pd.read_csv(os.path.join(data_folder, label_names_file))
            label_to_name = {str(row['Value']): row['Name'] for index, row in label_name_df.iterrows()}
            print(f"Loaded {len(label_to_name)} label names")
        except Exception as e:
            print(f"Error loading label names: {e}")
    
    # Create folders for images if saving
    if save_images:
        labeled_folder = os.path.join(data_folder, "labeled_images")
        unlabeled_folder = os.path.join(data_folder, "sampled_unlabeled_images")
        
        if os.path.exists(labeled_folder):
            shutil.rmtree(labeled_folder)
        os.makedirs(labeled_folder)
        if os.path.exists(unlabeled_folder):
            shutil.rmtree(unlabeled_folder)
        os.makedirs(unlabeled_folder)
    
    # First, get total count and file list
    total_plaques, files = get_total_plaques_count(data_folder)
    print(f"Total plaques available: {total_plaques}")
    print(f"Unlabeled sample size: {unlabeled_sample_size}")
    
    rows = []
    
    # Loop 1: Add all labeled samples from npz file
    print("Loop 1: Adding labeled samples from npz file...")
    try:
        with np.load(os.path.join(data_folder, label_file)) as f:
            for image, index, label in tqdm(zip(f['file_name'], f['local_idx'], f['label']), 
                                          total=len(f['file_name']), desc="Processing labeled samples"):
                file_path = os.path.join(data_folder, 'images', image)
                try:
                    with h5py.File(file_path, 'r') as h5f:
                        plaque = h5f['plaques'][str(index)]
                        
                        # Add to data table
                        rows.append([
                            image, 
                            str(index), 
                            plaque.attrs['roundness'], 
                            plaque.attrs['area'], 
                            label_to_name[str(int(label))] if not pd.isna(label) and str(int(label)) in label_to_name else ""
                        ])
                        
                        # Save image if requested
                        if save_images:
                            # Determine folder and filename
                            if str(int(label)) in label_to_name:
                                class_name = label_to_name[str(int(label))]
                            else:
                                class_name = f"class_{int(label)}"
                            
                            image_folder_path = os.path.join(labeled_folder, class_name)
                            if not os.path.exists(image_folder_path):
                                os.makedirs(image_folder_path)
                            
                            image_filename = f'{image.replace(".hdf5", "")}_index_{index}.png'
                            image_file_path = os.path.join(image_folder_path, image_filename)
                            
                            # Save image if it doesn't exist
                            if not os.path.exists(image_file_path):
                                plaque_image = plaque['plaque'][:]
                                img = Image.fromarray(plaque_image)
                                img_resized = img.resize(downsample_size)
                                img_resized.save(image_file_path)
                                
                except Exception as e:
                    print(f"Error processing labeled sample {image}, index {index}: {e}")
    except Exception as e:
        print(f"Error loading npz file: {e}")
    
    labeled_count = len(rows)
    print(f"Added {labeled_count} labeled samples")
    
    # Loop 2: Sample unlabeled data
    if unlabeled_sample_size > 0:
        print("Loop 2: Sampling unlabeled data...")
        
        # Create a set of already processed (image, index) pairs for quick lookup
        processed_pairs = set((row[0], row[1]) for row in rows)
        
        # Create list of all available unlabeled pairs
        unlabeled_pairs = []
        for image in tqdm(files, desc="Collecting unlabeled pairs"):
            file_path = os.path.join(data_folder, 'images', image)
            try:
                with h5py.File(file_path, 'r') as f:
                    plaques = f['plaques']
                    length = plaques.attrs['length']
                    for index in range(length):
                        if (image, str(index)) not in processed_pairs:
                            unlabeled_pairs.append((image, str(index)))
            except Exception as e:
                print(f"Error collecting unlabeled pairs from {image}: {e}")
        
        print(f"Available unlabeled pairs: {len(unlabeled_pairs)}")
        
        # Sample from unlabeled pairs
        if unlabeled_sample_size > len(unlabeled_pairs):
            print(f"Warning: Need {unlabeled_sample_size} unlabeled samples but only {len(unlabeled_pairs)} available")
            sampled_unlabeled = unlabeled_pairs
        else:
            sampled_unlabeled = random.sample(unlabeled_pairs, unlabeled_sample_size)
        
        # Add sampled unlabeled data
        for image, index in tqdm(sampled_unlabeled, desc="Processing unlabeled samples"):
            file_path = os.path.join(data_folder, 'images', image)
            try:
                with h5py.File(file_path, 'r') as f:
                    plaque = f['plaques'][index]
                    
                    # Add to data table
                    rows.append([
                        image, 
                        index, 
                        plaque.attrs['roundness'], 
                        plaque.attrs['area'], 
                        None  # Unlabeled
                    ])
                    
                    # Save image if requested
                    if save_images:
                        image_filename = f'{image.replace(".hdf5", "")}_index_{index}.png'
                        image_file_path = os.path.join(unlabeled_folder, image_filename)
                        
                        # Save image if it doesn't exist
                        if not os.path.exists(image_file_path):
                            plaque_image = plaque['plaque'][:]
                            img = Image.fromarray(plaque_image)
                            img_resized = img.resize(downsample_size)
                            img_resized.save(image_file_path)
                            
            except Exception as e:
                print(f"Error processing unlabeled sample {image}, index {index}: {e}")
    
    print(f"Final collection: {len(rows)} plaques (labeled: {labeled_count}, unlabeled: {len(rows) - labeled_count})")
    print(f"Total dataset size: {len(rows)} (all labeled + {unlabeled_sample_size} unlabeled)")
    
    if save_images:
        print(f"Images saved to:")
        print(f"  Labeled: {labeled_folder}")
        print(f"  Unlabeled: {unlabeled_folder}")
    
    return rows




def main():
    args = parse_arguments()
    DATA_FOLDER = args.data_dir
    UNLABELED_SAMPLE_SIZE = args.unlabeled_sample_size
    RANDOM_SEED = args.random_seed
    OUTPUT_FILE = args.output_file
    LABEL_FILE = args.label_file
    DOWNSAMPLE_SIZE = tuple(args.downsample_size)
    SAVE_IMAGES = args.save_images
    
    print(f"Starting sampled data table generation...")
    print(f"Data folder: {DATA_FOLDER}")
    print(f"Unlabeled sample size: {UNLABELED_SAMPLE_SIZE}")
    print(f"Random seed: {RANDOM_SEED}")
    print(f"Output file: {OUTPUT_FILE}")
    print(f"Downsample size: {DOWNSAMPLE_SIZE}")
    print(f"Save images: {SAVE_IMAGES}")
    
    # Create data table with labeled and unlabeled samples (and save images if requested)
    rows = create_data_table(
        DATA_FOLDER, 
        UNLABELED_SAMPLE_SIZE, 
        LABEL_FILE, 
        RANDOM_SEED,
        save_images=SAVE_IMAGES,
        downsample_size=DOWNSAMPLE_SIZE,
        label_names_file="label_names.csv"
    )
    
    if not rows:
        print("No plaques were collected. Exiting.")
        return
    
    # Create DataFrame
    df = pd.DataFrame(rows, columns=["Image", "Index", "Roundness", "Area", "Label"])
    
    # Save to file
    output_path = os.path.join(DATA_FOLDER, OUTPUT_FILE)
    df.to_csv(output_path, index=False)
    
    print(f"\nSampled data table saved to: {output_path}")
    print(f"Final dataset shape: {df.shape}")
    print(f"Sample of the data:")
    print(df.head())
    
    # Print some statistics
    print(f"\nStatistics:")
    print(f"Total plaques sampled: {len(df)}")
    print(f"Unique images: {df['Image'].nunique()}")
    print(f"Plaques with labels: {df['Label'].notna().sum()}")
    if df['Label'].notna().sum() > 0:
        print(f"Label distribution:")
        print(df['Label'].value_counts())

if __name__ == '__main__':
    main()
